-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 11, 2024 at 08:03 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jeffshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_product`
--

CREATE TABLE `tb_product` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `harga` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_product`
--

INSERT INTO `tb_product` (`id`, `nama`, `harga`) VALUES
(1, 'Winter Men\'s Boots', 'Rp.1.300.000'),
(2, 'Urban  Outfitters Ewings X33', 'Rp1.500.000'),
(3, 'BreathableFeature', 'Rp.1.200.000'),
(4, 'Men\'s Shoes Korean Style', 'Rp.1.400.000'),
(5, 'Breathable Graffiti Canvas', 'Rp.1.300.000'),
(6, 'Casual mens Shoes Tenis', 'Rp. 900.000'),
(7, 'Woment\'s Fashion Cool ', 'Rp.1.400.000'),
(8, ' Quanzhou Yimao', 'Rp. 900.000'),
(9, 'Sports Casual ShoesStyle', 'Rp.1.200.000'),
(10, 'Lemi Sneakers Upper', 'Rp.1.200.000'),
(11, 'Ortuseight Forte ', 'Rp. 900.000'),
(12, 'Nike footbal  boots', 'Rp.1.200.000'),
(13, 'CR7', 'Rp.1.400.000'),
(14, 'Nike Kyrie ', 'Rp.1.200.000'),
(15, 'Sneakers Papa Gading', 'Rp.450.000'),
(16, 'Nike', 'Rp. 900.000'),
(17, 'Flats Skateboard', 'Rp.400.000'),
(18, 'Vinthentic Men\'s Casual', 'Rp.400.000'),
(19, 'Air Jordan', 'Rp.1.200.000'),
(20, 'Nike Air Jordan', 'Rp.1.200.000'),
(21, 'Nike Air Jordan 1', 'Rp.1.200.000'),
(22, 'Nike Jordan Force', 'Rp.1.200.000'),
(23, ' Li-Ning Ranger VI ', 'Rp.800.000'),
(24, 'Adidas Copa 20.1 ', 'Rp.1.200.000'),
(25, 'adidas Inflight Pack', 'Rp.900.000'),
(26, 'basketshoes', 'Rp.1.200.000'),
(27, 'Nike dunk', 'Rp.1.500.000'),
(28, '', ''),
(29, 'fgdfg', 'Rp.1.500.000');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`) VALUES
(1, 'admin', '123456', 'admin@gmail.com'),
(2, 'jefri', '12345', 'jefribayu@gmail.com'),
(12, 'messi', '1234567', 'messi@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_product`
--
ALTER TABLE `tb_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_product`
--
ALTER TABLE `tb_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
