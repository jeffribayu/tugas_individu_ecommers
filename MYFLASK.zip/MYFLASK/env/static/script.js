
  const slider = document.querySelector('.product-slider');
  const productCards = document.querySelectorAll('.product-card');

  let scrollAmount = 0;

  function scrollRight() {
    scrollAmount += productCards[0].offsetWidth + 20;
    if (scrollAmount > slider.scrollWidth - slider.offsetWidth) {
      scrollAmount = slider.scrollWidth - slider.offsetWidth;
    }
    slider.scrollTo({
      left: scrollAmount,
      behavior: 'smooth',
    });
  }

  function scrollLeft() {
    scrollAmount -= productCards[0].offsetWidth + 20;
    if (scrollAmount < 0) {
      scrollAmount = 0;
    }
    slider.scrollTo({
      left: scrollAmount,
      behavior: 'smooth',
    });
  }



  var slideIndex = 0;
  showSlides();

  function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > slides.length) {
      slideIndex = 1;
    }
    slides[slideIndex - 1].style.display = "block";
    setTimeout(showSlides, 2000); // Ganti gambar setiap 2 detik (2000ms)
  }

     
  
  // Kode JavaScript untuk membuat efek slideshow otomatis
  var slideIndex = 0;
  showSlides();

  function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > slides.length) {
      slideIndex = 1;
    }
    slides[slideIndex - 1].style.display = "block";
    setTimeout(showSlides, 2000); // Ganti gambar setiap 2 detik (2000ms)
  }


  // Kode JavaScript untuk membuat efek slideshow otomatis
  var slideIndex = 0;
  showSlides();

  function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > slides.length) {
      slideIndex = 1;
    }
    slides[slideIndex - 1].style.display = "block";
    setTimeout(showSlides, 1000); // Ganti gambar setiap 2 detik (2000ms)
  }
  