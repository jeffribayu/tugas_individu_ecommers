
# Import Flask
from flask import Flask, render_template, session, request, redirect, url_for
from flask_mysqldb import MySQL

# Main app
app = Flask(__name__)

app.secret_key = 'your_secret_key'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'jeffshop'

mysql = MySQL(app)
@app.route('/')
def homepage():
    return render_template("homepage.html")

@app.route('/index')
def index():
    return render_template("index.html")

@app.route('/brand')
def brand():
    cur = mysql.connection.cursor() 
    # eksekusi kueri
    cur.execute("Select * FROM tb_product")
    # fetch hasil kueri masukkan ke var data
    data  = cur.fetchall()
    #tutup koneksi 
    cur.close()
    return render_template("brand.html",tb_product=data)

@app.route('/pay')
def pay():
    return render_template("pay.html")

@app.route('/Features')
def Features():
    return render_template("Features.html")

@app.route('/login', methods = ['GET', 'POST'])
def login():
    if request.method == 'POST' and 'inpEmail' in request.form and 'inpPass' in request.form:
        email = request.form['inpEmail']
        passwd = request.form['inpPass']
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users where email = %s and password = %s", (email, passwd))
        result = cur.fetchone()
        if result:
            session['is_logged_in'] = True
            session['username'] = result[1]
            return redirect(url_for('index'))
        else:
            return render_template('login.html')
    else:
        return render_template('login.html')

@app.route('/regist', methods = ['GET', 'POST'])
def register():
    if request.method == 'POST' and 'inpUsername' in request.form and 'inpEmail' in request.form and 'inpPass' in request.form:
        username = request.form['inpUsername']
        passwd = request.form['inpPass']
        email = request.form['inpEmail']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO users(username, password, email) VALUES (%s, %s, %s)",(username, passwd, email))
        mysql.connection.commit()
        cur.close()

        session['is_logged_in'] = True
        session['username'] = email
        return redirect(url_for('index'))
    else:
        return render_template('register.html')

@app.route('/logout')
def logout():
    session.pop('is_logged_in', None)
    session.pop('username', None)
    return redirect(url_for('homepage'))

# Debung, untuk automatic update server
if __name__ == "__main__":
    app.run(debug=True)

    